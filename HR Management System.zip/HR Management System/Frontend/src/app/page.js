"use client";
import withAuth from "./withAuth";

const Home = () => {
  return <section className="w-full"></section>;
};

export default withAuth(Home);
