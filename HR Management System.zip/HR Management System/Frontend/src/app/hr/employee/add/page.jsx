"use client";
import React from "react";
import Form from "./form";

const AddEmployeePage = () => {
  return <Form />;
};

export default React.memo(AddEmployeePage);
