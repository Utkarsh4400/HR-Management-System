import React from "react";

export default function Logo() {
  return (
    <img
      src="/chaincode_logo.svg"
      className="mx-auto"
      width={350}
      height={350}
    />
  );
}
